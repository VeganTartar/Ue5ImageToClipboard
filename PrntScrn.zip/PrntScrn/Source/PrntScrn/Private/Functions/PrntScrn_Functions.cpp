﻿// Copyright Umbral Studios,LLC. All Rights Reserved.

#include "Functions/PrntScrn_Functions.h"
#include "RenderingThread.h"
#include "Engine/TextureRenderTarget2D.h"
#include "RHI.h"
#include "RHICommandList.h"
#include "clip.h"
#include "TextureResource.h"

bool UPrntScrn_Functions::CopyTextureToClipboard(UTexture* Texture, EDesiredResolution option)
{
	//Gon modify 2021/10/10
#if PRNTSCRN_PLATFORM_SUPPORTED
	// Initialize an empty list of pixels for copying later
	TArray<FColor> TexturePixels;

	// If we received a render target, 
	if (UTextureRenderTarget2D* TextureRenderTarget = Cast<UTextureRenderTarget2D>(Texture))
	{
		// We must read its pixels in a unique way, so let's just do that now
		ReadPixelsFromRenderTextureTarget(TextureRenderTarget, TexturePixels);
		
		// And then copy the data to the clipboard
		switch (option)
		{
		UE_LOG(LogTemp, Warning, TEXT("The enum value is:: %i"), option);
		//UE_LOG(LogTemp, Warning, TEXT("The integer value is: %d"), option);
		case EDesiredResolution::a: 
			CopyImageDataToClipboard(TexturePixels, 480, 640);
			UE_LOG(LogTemp, Warning, TEXT("TexturePixels, 480, 640"));
			break;
		case EDesiredResolution::b:
			CopyImageDataToClipboard(TexturePixels, 768, 1024);
			UE_LOG(LogTemp, Warning, TEXT("TexturePixels, 768, 1024"));
			break;
		case EDesiredResolution::c:
			CopyImageDataToClipboard(TexturePixels, 1024, 1280);
			UE_LOG(LogTemp, Warning, TEXT("TexturePixels, 1024, 1280"));
			break;
		default:
			CopyImageDataToClipboard(TexturePixels, 480, 640);
			//CopyImageDataToClipboard(TexturePixels, TextureRenderTarget->SizeX, TextureRenderTarget->SizeY);
			break;

		}


		//CopyImageDataToClipboard(TexturePixels, TextureRenderTarget->SizeX, TextureRenderTarget->SizeY);

		return true;
	}

	// Otherwise, let's verify that the texture is supported
	if (!CanTextureBeCopied(Texture))
	{
		return false;
	}

	// Then get some information about the texture that we'll need later
	const FTextureRHIRef Texture2D = Texture->GetResource()->TextureRHI;
	const FTextureSummary ImageFormatContext = GetTextureSummary(Texture2D);

	// Otherwise just render the pixels in the rendering thread and save them to the array 
	ReadPixelsFromTexture(Texture2D, ImageFormatContext, TexturePixels);

	// Finally, save the pixels to the clipboard
	CopyImageDataToClipboard(TexturePixels, ImageFormatContext.Width, ImageFormatContext.Height);
	return true;
#else
	// Return false because library is not supported on this platform
	return false;
#endif
}

bool UPrntScrn_Functions::CanTextureBeCopied(UTexture* Texture)
{
#if PRNTSCRN_PLATFORM_SUPPORTED

	if (Cast<UTextureRenderTarget2D>(Texture))
	{
		return true;
	}

	if (!Texture || !Texture->GetResource() || !Texture->GetResource()->TextureRHI)
	{
		UE_LOG(LogTemp, Warning, TEXT("Invalid Texture"));
		return false;
	}

	if (!IsFormatSupported(Texture->GetResource()->TextureRHI->GetDesc().Format))
	{
		UE_LOG(LogTemp, Warning, TEXT("Unsupported image format."));
		return false;
	}

	return true;
#else
	// Return false because library is not supported on this platform
	return false;
#endif
}

bool UPrntScrn_Functions::IsFormatSupported(const EPixelFormat Format)
{
	// Hardcoded the 4 formats this plugin will support
	switch (Format)
	{
	case PF_B8G8R8A8:
	case PF_R8G8B8A8:
	case PF_FloatRGBA:
	case PF_FloatRGB: return true;
	default: return false;
	}
}

void UPrntScrn_Functions::ReadPixelsFromRenderTextureTarget(UTextureRenderTarget2D* TextureRenderTarget, TArray<FColor>& OutPixels)
{
	// Read all the pixels to the array we defined earlier
	FRenderTarget* RenderTarget = TextureRenderTarget->GameThread_GetRenderTargetResource();
	RenderTarget->ReadPixels(OutPixels);

	// Then set alpha to 255 for all pixels if it wasn't set, as it typically sets alpha to 0
	if (OutPixels.Num() > 0 && OutPixels[0].A == 0)
	{
		for (int i = 0; i < OutPixels.Num(); i++)
		{
			const FColor* CurrentColor = &OutPixels[i];
			OutPixels[i] = CurrentColor->WithAlpha(255);
		}
	}
}

void UPrntScrn_Functions::ReadPixelsFromTexture(
	const FTextureRHIRef& Texture2D,
	const FTextureSummary& ImageFormatContext,
	TArray<FColor>& OutPixels
)
{
	// Initialize settings for reading pixels from rendering thread
	FReadSurfaceContext ReadSurfaceContext = {
		Texture2D,
		&OutPixels,
		FIntRect(0, 0, ImageFormatContext.Width, ImageFormatContext.Height),
		FReadSurfaceDataFlags(RCM_UNorm, CubeFace_MAX)
	};

	// Reads the texture in the render thread
	ENQUEUE_RENDER_COMMAND(ReadSurfaceCommand)(
		[ReadSurfaceContext](FRHICommandListImmediate& RHICmdList)
		{
			RHICmdList.ReadSurfaceData(
				ReadSurfaceContext.Texture,
				ReadSurfaceContext.Rect,
				*ReadSurfaceContext.OutData,
				ReadSurfaceContext.Flags
			);
		}
	);

	// Wait for command to finish in the rendering thread before continuing
	FlushRenderingCommands();
}

FTextureSummary UPrntScrn_Functions::GetTextureSummary(const FTexture2DRHIRef& Texture2D)
{
	const int32 Width = Texture2D->GetSizeX();
	const int32 Height = Texture2D->GetSizeY();
	const EPixelFormat PixelFormat = Texture2D->GetDesc().Format;
	return FTextureSummary(Width, Height, PixelFormat);
}

void UPrntScrn_Functions::CopyImageDataToClipboard(TArray<FColor>& Pixels, const int Width, const int Height)
{
	TArray<uint32> PackedPixels;
	TArray<float> PackedPixelsFloats;

	UE_LOG(LogTemp, Display, TEXT("Reformatting colors..."))
	for (const FColor& Color : Pixels)
	{
		PackedPixels.Add(Color.ToPackedABGR());
	}

	UE_LOG(LogTemp, Display, TEXT("Copying image..."))
	clip::image_spec Spec;
	Spec.width = Width;
	Spec.height = Height;
	Spec.bits_per_pixel = 32;
	Spec.bytes_per_row = (Spec.bits_per_pixel / 8) * Width;
	Spec.red_mask = 0xff;
	Spec.green_mask = 0xff00;
	Spec.blue_mask = 0xff0000;
	Spec.alpha_mask = 0xff000000;
	Spec.red_shift = 0;
	Spec.green_shift = 8;
	Spec.blue_shift = 16;
	Spec.alpha_shift = 24;

	clip::image img(PackedPixels.GetData(), Spec);
	clip::set_image(img);

	UE_LOG(LogTemp, Log, TEXT("Image copied to clipboard"));
	UE_LOG(LogTemp, Warning, TEXT("The integer value is: %d"));
}
