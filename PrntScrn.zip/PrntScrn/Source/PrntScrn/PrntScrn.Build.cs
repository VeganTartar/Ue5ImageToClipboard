// Copyright Epic Games, Inc. All Rights Reserved.

using System.IO;
using UnrealBuildTool;

public class PrntScrn : ModuleRules
{
	private string ModulePath
	{
		get { return ModuleDirectory; }
	}

	private string ThirdPartyPath
	{
		get { return Path.GetFullPath(Path.Combine(ModulePath, "../ThirdParty/")); }
	}


	public PrntScrn(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

		LoadClipLibrary(Target);

		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				"Core",
				"CoreUObject",
				"Engine",
				"InputCore",
				"RHI",
				"RenderCore",
				"Slate",
				"SlateCore",
				"ImageCore"
			}
		);
	}


	public bool LoadClipLibrary(ReadOnlyTargetRules Target)
	{
        var isWindows = Target.Platform == UnrealTargetPlatform.Win64;
        var isMac = Target.Platform == UnrealTargetPlatform.Mac;
		var isLibrarySupported = isWindows || isMac;
		var librariesPath = Path.Combine(ThirdPartyPath, "Clip", "Libraries");
		var libraryPath = "";
		
		if (isWindows)
		{
			libraryPath = Path.Combine(librariesPath, "win_x64.lib");
		}
		else if (isMac)
		{
			libraryPath = Path.Combine(librariesPath, "mac_universal.a");
		}
		
		if (isLibrarySupported)
		{
			PublicAdditionalLibraries.Add(libraryPath);
			PublicIncludePaths.Add(Path.Combine(ThirdPartyPath, "Clip", "Includes"));
		}

		// To determine if the library is supported on the current platform
		PublicDefinitions.Add(string.Format("PRNTSCRN_PLATFORM_SUPPORTED={0}", isLibrarySupported ? 1 : 0));
		// Add library settings
		PublicDefinitions.Add("CLIP_ENABLE_IMAGE=1");
		PublicDefinitions.Add("CLIP_ENABLE_LIST_FORMATS=0");

		if (Target.Platform == UnrealTargetPlatform.Win64)
		{
			// Ensure the path to the library is set
			string windowsSdkDir = Target.WindowsPlatform.WindowsSdkDir;
			string windowsSdkVersion = Target.WindowsPlatform.WindowsSdkVersion;
			string shlwapiLibPath = Path.Combine(windowsSdkDir, "Lib", windowsSdkVersion, "um", "x64", "ShLwApi.Lib");
			PublicAdditionalLibraries.Add(shlwapiLibPath);
		}

		return isLibrarySupported;
	}
}