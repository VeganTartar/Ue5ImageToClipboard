﻿// Copyright Umbral Studios,LLC. All Rights Reserved.
#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "Engine/Texture.h"
#include "RHICommandList.h"
#include "Runtime/Engine/Classes/Engine/TextureRenderTarget2D.h"
#include "Runtime/Engine/Classes/Kismet/BlueprintFunctionLibrary.h"
#include "PrntScrn_Functions.generated.h"

UENUM(BlueprintType)
enum class EDesiredResolution : uint8
{
	a,
	b,
	c,
	d

};


// Used to read pixels from render thread
struct FReadSurfaceContext
{
	FTexture2DRHIRef Texture;

	TArray<FColor>* OutData;

	FIntRect Rect;

	FReadSurfaceDataFlags Flags;
};

// Holds useful info frequently needed about an image
struct FTextureSummary
{
	FTextureSummary(): Width(0), Height(0), PixelFormat(PF_Unknown) {}

	FTextureSummary(const int32 Width, const int32 Height, const EPixelFormat PixelFormat) : Width(Width),
		Height(Height),
		PixelFormat(PixelFormat) {}

	const int32 Width;

	const int32 Height;

	const EPixelFormat PixelFormat;
};

UCLASS()
class PRNTSCRN_API UPrntScrn_Functions : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	// Copies the given texture to the clipboard
	UFUNCTION(BlueprintCallable, Category="PrntScrn")
	static bool CopyTextureToClipboard(UTexture* Texture, EDesiredResolution option);

	// Determines if the given texture can be copied to the clipboard, as it may not be supported
	UFUNCTION(BlueprintCallable, Category="PrntScrn")
	static bool CanTextureBeCopied(UTexture* Texture);

private:
	// Determines if the given format is supported by this plugin
	static bool IsFormatSupported(const EPixelFormat Format);

	// Reads the pixels on the TextureRenderTarget and saves them in the given array
	static void ReadPixelsFromRenderTextureTarget(UTextureRenderTarget2D* TextureRenderTarget, TArray<FColor>& OutPixels);

	// Reads the texture in the render thread and outputs pixels to the given array
	static void ReadPixelsFromTexture(
		const FTextureRHIRef& Texture2D,
		const FTextureSummary& ImageFormatContext,
		TArray<FColor>& OutPixels
	);

	// Returns common information about the given texture
	static FTextureSummary GetTextureSummary(const FTexture2DRHIRef& Texture2D);

	// Copies the pixels to the clipboard
	static void CopyImageDataToClipboard(TArray<FColor>& Pixels, const int Width, const int Height);
};
